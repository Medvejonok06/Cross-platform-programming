package com.example.demo.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
public class SecurityConfig {

    //Метод, що створює та повертає SecurityFilterChain — головний механізм налаштування безпеки HTTP
    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http
                //Вимикає захист від CSRF-атак
                .csrf().disable()

                //Налаштування доступу до URL-адрес
                .authorizeHttpRequests(auth -> auth
                        //Дозволяє без автентифікації доступ до сторінки реєстрації та статичних ресурсів (CSS, JS)
                        .requestMatchers("/register", "/api/register", "/css/**", "/js/**").permitAll()
                        //Всі інші запити вимагають автентифікації
                        .anyRequest().authenticated()
                )

                //Налаштування форми логіну
                .formLogin(login -> login
                        //Вказує власну сторінку логіну
                        .loginPage("/login")
                        //Дозволяє доступ до цієї сторінки всім
                        .permitAll()
                )

                //Налаштування виходу з системи (logout)
                .logout(logout -> logout.permitAll());

        //Повертає побудований ланцюг фільтрів безпеки
        return http.build();
    }
}
