package com.example.demo.controller;

import com.example.demo.dto.UserRegistrationDto;
import com.example.demo.entity.User;
import com.example.demo.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.web.bind.annotation.*;

@RestController

//Встановлює базовий шлях для всіх запитів у цьому контролері: /api/...
@RequestMapping("/api")
public class UserRegistrationController {

    //Залежності: репозиторій користувачів та енкодер паролів
    private final UserRepository userRepository;
    private final BCryptPasswordEncoder passwordEncoder;

    //Конструктор з ін’єкцією залежностей
    @Autowired
    public UserRegistrationController(UserRepository userRepository, BCryptPasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
    }

    //Обробляє POST-запити за адресою /api/register
    //Приймає дані з форми (DTO) через @ModelAttribute
    @PostMapping("/register")
    public String registerUser(@ModelAttribute UserRegistrationDto registrationDto) {
        //Створення нового користувача та заповнення його даними з DTO
        User user = new User();
        user.setUsername(registrationDto.getUsername());
        //Пароль хешується перед збереженням
        user.setPassword(passwordEncoder.encode(registrationDto.getPassword()));
        user.setRole(registrationDto.getRole());

        //Збереження користувача в базі даних
        userRepository.save(user);

        return "Користувач створений!";
    }
}
