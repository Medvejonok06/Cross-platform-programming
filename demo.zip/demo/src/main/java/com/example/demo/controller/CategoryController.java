package com.example.demo.controller;

import com.example.demo.entity.Category;
import com.example.demo.repository.CategoryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class CategoryController {

    //Репозиторій для доступу до таблиці/сутності категорій
    private final CategoryRepository categoryRepository;

    //Конструктор з автоматичною ін'єкцією CategoryRepository
    @Autowired
    public CategoryController(CategoryRepository categoryRepository) {
        this.categoryRepository = categoryRepository;
    }

    //Обробляє GET-запити за адресою /categories
    //Завантажує всі категорії з бази даних та додає їх у модель (для подальшого відображення на сторінці)
    @GetMapping({"/categories"})
    public String showCategories(Model model) {
        Iterable<Category> categories = this.categoryRepository.findAll();
        model.addAttribute("categories", categories); //передає список категорій до шаблону
        return "categories";
    }

    //Обробляє GET-запити за адресою /
    //Робить редірект на /categories
    @GetMapping({"/"})
    public String redirectToCategories() {
        return "redirect:/categories";
    }
}
