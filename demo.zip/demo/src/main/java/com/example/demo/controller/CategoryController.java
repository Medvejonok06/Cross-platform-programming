package com.example.demo.controller;

import com.example.demo.entity.Category;
import com.example.demo.repository.CategoryRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller //Позначає клас як Spring MVC контролер
public class CategoryController {

    private final CategoryRepository categoryRepository;

    //Ін’єкція репозиторію категорій через конструктор
    @Autowired
    public CategoryController(CategoryRepository categoryRepository) {
        this.categoryRepository = categoryRepository;
    }

    //Показ усіх категорій
    @GetMapping("/categories")
    public String showCategories(Model model) {
        Iterable<Category> categories = categoryRepository.findAll(); //отримаємо всі категорії з БД
        model.addAttribute("categories", categories); //передаємо список до шаблону
        return "categories";
    }

    //Редірект з головної сторінки на список категорій
    @GetMapping("/")
    public String redirectToCategories() {
        return "redirect:/categories";
    }

    //Показ форми для додавання нової категорії
    @GetMapping("/categories/add")
    public String showAddCategoryForm() {
        return "add-category";
    }

    //Обробка POST-запиту для створення нової категорії
    @PostMapping("/categories/save")
    public String saveNewCategory(@RequestParam String name) {
        Category category = new Category();
        category.setName(name);
        categoryRepository.save(category);
        return "redirect:/categories";
    }

    //Показ форми редагування існуючої категорії
    @GetMapping("/categories/edit/{id}")
    public String showEditForm(@PathVariable Long id, Model model) {
        //пошук категорії за ID або помилка, якщо не знайдено
        Category category = categoryRepository.findById(id)
                .orElseThrow(() -> new IllegalArgumentException("Невірний ID категорії: " + id));
        model.addAttribute("category", category); //передаємо у шаблон
        return "edit-category";
    }

    //Обробка оновлення категорії
    @PostMapping("/categories/update")
    public String updateCategory(@RequestParam Long categoryId,
                                 @RequestParam String name) {
        //пошук категорії
        Category category = categoryRepository.findById(categoryId)
                .orElseThrow(() -> new IllegalArgumentException("Невірний ID категорії: " + categoryId));
        category.setName(name);
        categoryRepository.save(category);
        return "redirect:/categories";
    }

    //Обробка видалення категорії
    @PostMapping("/categories/delete")
    public String deleteCategory(@RequestParam Long categoryId) {
        //пошук категорії перед видаленням
        Category category = categoryRepository.findById(categoryId)
                .orElseThrow(() -> new IllegalArgumentException("Невірний ID категорії: " + categoryId));
        categoryRepository.delete(category);
        return "redirect:/categories";
    }
}
