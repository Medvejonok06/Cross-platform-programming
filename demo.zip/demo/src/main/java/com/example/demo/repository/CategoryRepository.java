package com.example.demo.repository;

import com.example.demo.entity.Category;
import org.springframework.data.repository.CrudRepository;

import java.util.List;

public interface CategoryRepository extends CrudRepository<Category, Long> {
    Category findByName(String name);

    //Сортування за зростанням
    List<Category> findAllByOrderByNameAsc();

    //Сортування за спаданням
    List<Category> findAllByOrderByNameDesc();

    //Пошук за частиною назви
    List<Category> findByNameContainingIgnoreCase(String keyword);
}






