package gg.jte.generated.ondemand;
import com.example.demo.entity.Category;
import org.springframework.security.core.context.SecurityContextHolder;
@SuppressWarnings("unchecked")
public final class JtecategoriesGenerated {
	public static final String JTE_NAME = "categories.jte";
	public static final int[] JTE_LINE_INFO = {0,0,1,2,2,2,2,115,115,115,117,117,120,120,122,122,122,123,123,125,125,125,125,127,127,127,127,127,127,127,127,127,131,131,133,133,142,142,142,2,2,2,2};
	public static void render(gg.jte.html.HtmlTemplateOutput jteOutput, gg.jte.html.HtmlInterceptor jteHtmlInterceptor, Iterable<Category> categories) {
		jteOutput.writeContent("\r\n<!DOCTYPE html>\r\n<html lang=\"uk\">\r\n<head>\r\n    <meta charset=\"UTF-8\">\r\n    <title>Категорії</title>\r\n    <style>\r\n        body {\r\n            font-family: 'Segoe UI', sans-serif;\r\n            background: linear-gradient(to right, #FFDEE9, #B5FFFC);\r\n            margin: 0;\r\n            padding: 0;\r\n            display: flex;\r\n            justify-content: center;\r\n            align-items: center;\r\n            height: 100vh;\r\n        }\r\n\r\n        .container {\r\n            background-color: #fff;\r\n            padding: 40px;\r\n            border-radius: 16px;\r\n            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.15);\r\n            max-width: 600px;\r\n            width: 100%;\r\n            text-align: center;\r\n        }\r\n\r\n        h1 {\r\n            margin-bottom: 24px;\r\n            color: #333;\r\n        }\r\n\r\n        .add-button {\r\n            display: inline-block;\r\n            margin-bottom: 16px;\r\n            padding: 8px 16px;\r\n            background-color: #28a745;\r\n            color: white;\r\n            border-radius: 6px;\r\n            text-decoration: none;\r\n            font-weight: bold;\r\n        }\r\n\r\n        .add-button:hover {\r\n            background-color: #218838;\r\n        }\r\n\r\n        ul {\r\n            list-style: none;\r\n            padding: 0;\r\n        }\r\n\r\n        li {\r\n            background-color: #f9f9f9;\r\n            margin-bottom: 12px;\r\n            padding: 12px 16px;\r\n            border-radius: 8px;\r\n            font-size: 18px;\r\n            color: #444;\r\n            display: flex;\r\n            justify-content: space-between;\r\n            align-items: center;\r\n        }\r\n\r\n        .edit-link, .delete-button {\r\n            padding: 6px 12px;\r\n            border: none;\r\n            border-radius: 6px;\r\n            font-size: 14px;\r\n            cursor: pointer;\r\n            transition: 0.3s;\r\n        }\r\n\r\n        .edit-link {\r\n            background-color: #007BFF;\r\n            color: white;\r\n            text-decoration: none;\r\n        }\r\n\r\n        .edit-link:hover {\r\n            background-color: #0056b3;\r\n        }\r\n\r\n        .delete-button {\r\n            background-color: #dc3545;\r\n            color: white;\r\n        }\r\n\r\n        .delete-button:hover {\r\n            background-color: #c82333;\r\n        }\r\n\r\n        .footer {\r\n            margin-top: 20px;\r\n            font-size: 14px;\r\n        }\r\n\r\n        .footer a {\r\n            color: #333;\r\n            text-decoration: none;\r\n        }\r\n\r\n        .footer a:hover {\r\n            text-decoration: underline;\r\n        }\r\n    </style>\r\n</head>\r\n<body>\r\n<div class=\"container\">\r\n    <h1>Список категорій</h1>\r\n\r\n    ");
		if (SecurityContextHolder.getContext().getAuthentication().getAuthorities().toString().contains("ROLE_ADMIN")) {
			jteOutput.writeContent("\r\n        <a href=\"/categories/add\" class=\"add-button\">➕ Додати категорію</a>\r\n    ");
		}
		jteOutput.writeContent("\r\n\r\n    <ul>\r\n        ");
		for (Category category : categories) {
			jteOutput.writeContent("\r\n            <li>\r\n                ");
			jteOutput.setContext("li", null);
			jteOutput.writeUserContent(category.getName());
			jteOutput.writeContent("\r\n                ");
			if (SecurityContextHolder.getContext().getAuthentication().getAuthorities().toString().contains("ROLE_ADMIN")) {
				jteOutput.writeContent("\r\n                    <div>\r\n                        <a href=\"/categories/edit/");
				jteOutput.setContext("a", "href");
				jteOutput.writeUserContent(category.getCategoryId());
				jteOutput.setContext("a", null);
				jteOutput.writeContent("\" class=\"edit-link\">Редагувати</a>\r\n                        <form action=\"/categories/delete\" method=\"post\" style=\"display:inline;\" onsubmit=\"return confirm('Ви впевнені, що хочете видалити цю категорію?');\">\r\n                            <input type=\"hidden\" name=\"categoryId\"");
				var __jte_html_attribute_0 = category.getCategoryId();
				if (gg.jte.runtime.TemplateUtils.isAttributeRendered(__jte_html_attribute_0)) {
					jteOutput.writeContent(" value=\"");
					jteOutput.setContext("input", "value");
					jteOutput.writeUserContent(__jte_html_attribute_0);
					jteOutput.setContext("input", null);
					jteOutput.writeContent("\"");
				}
				jteOutput.writeContent(">\r\n                            <button type=\"submit\" class=\"delete-button\">Видалити</button>\r\n                        </form>\r\n                    </div>\r\n                ");
			}
			jteOutput.writeContent("\r\n            </li>\r\n        ");
		}
		jteOutput.writeContent("\r\n    </ul>\r\n\r\n    <div class=\"footer\">\r\n        <a href=\"/logout\">Вийти з акаунту</a>\r\n    </div>\r\n</div>\r\n</body>\r\n</html>\r\n");
	}
	public static void renderMap(gg.jte.html.HtmlTemplateOutput jteOutput, gg.jte.html.HtmlInterceptor jteHtmlInterceptor, java.util.Map<String, Object> params) {
		Iterable<Category> categories = (Iterable<Category>)params.get("categories");
		render(jteOutput, jteHtmlInterceptor, categories);
	}
}
