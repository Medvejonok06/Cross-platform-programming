package gg.jte.generated.ondemand;
import com.example.demo.entity.Category;
@SuppressWarnings("unchecked")
public final class JtecategoriesGenerated {
	public static final String JTE_NAME = "categories.jte";
	public static final int[] JTE_LINE_INFO = {0,0,1,1,1,1,74,74,74,75,75,75,76,76,84,84,84,1,1,1,1};
	public static void render(gg.jte.html.HtmlTemplateOutput jteOutput, gg.jte.html.HtmlInterceptor jteHtmlInterceptor, Iterable<Category> categories) {
		jteOutput.writeContent("\r\n<!DOCTYPE html>\r\n<html lang=\"uk\">\r\n<head>\r\n    <meta charset=\"UTF-8\">\r\n    <title>Категорії</title>\r\n    <style>\r\n        body {\r\n            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;\r\n            background: linear-gradient(to right, #FFDEE9, #B5FFFC);\r\n            margin: 0;\r\n            padding: 0;\r\n            display: flex;\r\n            justify-content: center;\r\n            align-items: center;\r\n            height: 100vh;\r\n        }\r\n\r\n        .container {\r\n            background-color: #fff;\r\n            padding: 40px;\r\n            border-radius: 16px;\r\n            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.15);\r\n            max-width: 500px;\r\n            width: 100%;\r\n            text-align: center;\r\n        }\r\n\r\n        h1 {\r\n            margin-bottom: 24px;\r\n            color: #333;\r\n        }\r\n\r\n        ul {\r\n            list-style-type: none;\r\n            padding: 0;\r\n        }\r\n\r\n        li {\r\n            background-color: #f2f2f2;\r\n            margin: 10px 0;\r\n            padding: 12px 16px;\r\n            border-radius: 8px;\r\n            font-size: 18px;\r\n            color: #444;\r\n            transition: background-color 0.3s;\r\n        }\r\n\r\n        li:hover {\r\n            background-color: #e0e0e0;\r\n        }\r\n\r\n        .footer {\r\n            margin-top: 20px;\r\n            font-size: 14px;\r\n            color: #666;\r\n        }\r\n\r\n        .footer a {\r\n            color: #333;\r\n            text-decoration: none;\r\n        }\r\n\r\n        .footer a:hover {\r\n            text-decoration: underline;\r\n        }\r\n    </style>\r\n</head>\r\n<body>\r\n<div class=\"container\">\r\n    <h1>Список категорій</h1>\r\n    <ul>\r\n        ");
		for (Category category : categories) {
			jteOutput.writeContent("\r\n            <li>");
			jteOutput.setContext("li", null);
			jteOutput.writeUserContent(category.getName());
			jteOutput.writeContent("</li>\r\n        ");
		}
		jteOutput.writeContent("\r\n    </ul>\r\n    <div class=\"footer\">\r\n        <a href=\"/logout\">Вийти з акаунту</a>\r\n    </div>\r\n</div>\r\n</body>\r\n</html>\r\n");
	}
	public static void renderMap(gg.jte.html.HtmlTemplateOutput jteOutput, gg.jte.html.HtmlInterceptor jteHtmlInterceptor, java.util.Map<String, Object> params) {
		Iterable<Category> categories = (Iterable<Category>)params.get("categories");
		render(jteOutput, jteHtmlInterceptor, categories);
	}
}
