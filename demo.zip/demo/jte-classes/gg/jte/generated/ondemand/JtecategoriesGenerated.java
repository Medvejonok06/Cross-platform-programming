package gg.jte.generated.ondemand;
import com.example.demo.entity.Category;
import org.springframework.security.core.context.SecurityContextHolder;
@SuppressWarnings("unchecked")
public final class JtecategoriesGenerated {
	public static final String JTE_NAME = "categories.jte";
	public static final int[] JTE_LINE_INFO = {0,0,1,2,2,2,2,159,159,159,159,159,159,159,159,159,159,169,169,171,171,174,174,176,176,176,177,177,179,179,179,179,181,181,181,181,181,181,181,181,181,185,185,187,187,196,196,196,2,3,4,4,4,4};
	public static void render(gg.jte.html.HtmlTemplateOutput jteOutput, gg.jte.html.HtmlInterceptor jteHtmlInterceptor, Iterable<Category> categories, String sort, String search) {
		jteOutput.writeContent("\r\n<!DOCTYPE html>\r\n<html lang=\"uk\">\r\n<head>\r\n    <meta charset=\"UTF-8\">\r\n    <title>Категорії</title>\r\n    <style>\r\n        body {\r\n            font-family: 'Segoe UI', sans-serif;\r\n            background: #f0f2f5;\r\n            display: flex;\r\n            justify-content: center;\r\n            align-items: start;\r\n            padding-top: 60px;\r\n        }\r\n\r\n        .container {\r\n            background: white;\r\n            padding: 40px;\r\n            border-radius: 16px;\r\n            box-shadow: 0 8px 20px rgba(0,0,0,0.1);\r\n            width: 600px;\r\n        }\r\n\r\n        h1 {\r\n            margin-bottom: 20px;\r\n            text-align: center;\r\n        }\r\n\r\n        .search-box {\r\n            margin-bottom: 20px;\r\n            text-align: center;\r\n        }\r\n\r\n        .search-box input[type=\"text\"] {\r\n            padding: 8px;\r\n            width: 250px;\r\n            border-radius: 6px;\r\n            border: 1px solid #ccc;\r\n            margin-right: 8px;\r\n        }\r\n\r\n        .search-box button {\r\n            padding: 8px 14px;\r\n            background-color: #17a2b8;\r\n            color: white;\r\n            border: none;\r\n            border-radius: 6px;\r\n            cursor: pointer;\r\n        }\r\n\r\n        .search-box button:hover {\r\n            background-color: #138496;\r\n        }\r\n\r\n        .sort-buttons {\r\n            margin-bottom: 16px;\r\n            text-align: center;\r\n        }\r\n\r\n        .sort-buttons a {\r\n            display: inline-block;\r\n            margin: 6px 8px;\r\n            padding: 10px 20px;\r\n            background-color: #007BFF;\r\n            color: white;\r\n            text-decoration: none;\r\n            border-radius: 6px;\r\n            font-size: 14px;\r\n        }\r\n\r\n        .sort-buttons a:hover {\r\n            background-color: #0056b3;\r\n        }\r\n\r\n        .add-button {\r\n            display: inline-block;\r\n            margin-bottom: 16px;\r\n            padding: 10px 20px;\r\n            background-color: #28a745;\r\n            color: white;\r\n            border-radius: 6px;\r\n            text-decoration: none;\r\n            font-weight: bold;\r\n        }\r\n\r\n        .add-button:hover {\r\n            background-color: #218838;\r\n        }\r\n\r\n        ul {\r\n            list-style: none;\r\n            padding: 0;\r\n        }\r\n\r\n        li {\r\n            padding: 12px;\r\n            margin-bottom: 12px;\r\n            background-color: #f9f9f9;\r\n            border-radius: 8px;\r\n            display: flex;\r\n            justify-content: space-between;\r\n            align-items: center;\r\n        }\r\n\r\n        .edit-link, .delete-button {\r\n            padding: 6px 10px;\r\n            font-size: 14px;\r\n            margin-left: 4px;\r\n            border-radius: 6px;\r\n            border: none;\r\n            cursor: pointer;\r\n        }\r\n\r\n        .edit-link {\r\n            background-color: #17a2b8;\r\n            color: white;\r\n            text-decoration: none;\r\n        }\r\n\r\n        .edit-link:hover {\r\n            background-color: #138496;\r\n        }\r\n\r\n        .delete-button {\r\n            background-color: #dc3545;\r\n            color: white;\r\n        }\r\n\r\n        .delete-button:hover {\r\n            background-color: #c82333;\r\n        }\r\n\r\n        .footer {\r\n            text-align: center;\r\n            margin-top: 24px;\r\n        }\r\n\r\n        .footer a {\r\n            color: #555;\r\n            text-decoration: none;\r\n        }\r\n\r\n        .footer a:hover {\r\n            text-decoration: underline;\r\n        }\r\n    </style>\r\n</head>\r\n<body>\r\n<div class=\"container\">\r\n    <h1>Список категорій</h1>\r\n\r\n    <div class=\"search-box\">\r\n        <form action=\"/categories\" method=\"get\">\r\n            <input type=\"text\" name=\"search\" placeholder=\"Пошук категорії...\"");
		var __jte_html_attribute_0 = search;
		if (gg.jte.runtime.TemplateUtils.isAttributeRendered(__jte_html_attribute_0)) {
			jteOutput.writeContent(" value=\"");
			jteOutput.setContext("input", "value");
			jteOutput.writeUserContent(__jte_html_attribute_0);
			jteOutput.setContext("input", null);
			jteOutput.writeContent("\"");
		}
		jteOutput.writeContent(" />\r\n            <button type=\"submit\">🔍 Знайти</button>\r\n        </form>\r\n    </div>\r\n\r\n    <div class=\"sort-buttons\">\r\n        <a href=\"/categories?sort=asc\">Сортування в алфавітному порядку (А → Я)</a>\r\n        <a href=\"/categories?sort=desc\">Сортування в алфавітному порядку (Я → А)</a>\r\n    </div>\r\n\r\n    ");
		if (SecurityContextHolder.getContext().getAuthentication().getAuthorities().toString().contains("ROLE_ADMIN")) {
			jteOutput.writeContent("\r\n        <a href=\"/categories/add\" class=\"add-button\">➕ Додати категорію</a>\r\n    ");
		}
		jteOutput.writeContent("\r\n\r\n    <ul>\r\n        ");
		for (Category category : categories) {
			jteOutput.writeContent("\r\n            <li>\r\n                ");
			jteOutput.setContext("li", null);
			jteOutput.writeUserContent(category.getName());
			jteOutput.writeContent("\r\n                ");
			if (SecurityContextHolder.getContext().getAuthentication().getAuthorities().toString().contains("ROLE_ADMIN")) {
				jteOutput.writeContent("\r\n                    <div>\r\n                        <a href=\"/categories/edit/");
				jteOutput.setContext("a", "href");
				jteOutput.writeUserContent(category.getCategoryId());
				jteOutput.setContext("a", null);
				jteOutput.writeContent("\" class=\"edit-link\">Редагувати</a>\r\n                        <form action=\"/categories/delete\" method=\"post\" style=\"display:inline;\" onsubmit=\"return confirm('Видалити категорію?');\">\r\n                            <input type=\"hidden\" name=\"categoryId\"");
				var __jte_html_attribute_1 = category.getCategoryId();
				if (gg.jte.runtime.TemplateUtils.isAttributeRendered(__jte_html_attribute_1)) {
					jteOutput.writeContent(" value=\"");
					jteOutput.setContext("input", "value");
					jteOutput.writeUserContent(__jte_html_attribute_1);
					jteOutput.setContext("input", null);
					jteOutput.writeContent("\"");
				}
				jteOutput.writeContent(">\r\n                            <button class=\"delete-button\" type=\"submit\">Видалити</button>\r\n                        </form>\r\n                    </div>\r\n                ");
			}
			jteOutput.writeContent("\r\n            </li>\r\n        ");
		}
		jteOutput.writeContent("\r\n    </ul>\r\n\r\n    <div class=\"footer\">\r\n        <a href=\"/logout\">Вийти з акаунту</a>\r\n    </div>\r\n</div>\r\n</body>\r\n</html>\r\n");
	}
	public static void renderMap(gg.jte.html.HtmlTemplateOutput jteOutput, gg.jte.html.HtmlInterceptor jteHtmlInterceptor, java.util.Map<String, Object> params) {
		Iterable<Category> categories = (Iterable<Category>)params.get("categories");
		String sort = (String)params.get("sort");
		String search = (String)params.get("search");
		render(jteOutput, jteHtmlInterceptor, categories, sort, search);
	}
}
