package gg.jte.generated.ondemand;
@SuppressWarnings("unchecked")
public final class JteregisterGenerated {
	public static final String JTE_NAME = "register.jte";
	public static final int[] JTE_LINE_INFO = {22,22,22,22,22,22,22,22,22,22,22,22};
	public static void render(gg.jte.html.HtmlTemplateOutput jteOutput, gg.jte.html.HtmlInterceptor jteHtmlInterceptor) {
		jteOutput.writeContent("<!DOCTYPE html>\r\n<html>\r\n<head>\r\n    <meta charset=\"UTF-8\">\r\n    <title>Реєстрація</title>\r\n</head>\r\n<body>\r\n<h1>Реєстрація</h1>\r\n<form action=\"/api/register\" method=\"post\">\r\n    <label for=\"username\">Ім’я користувача:</label>\r\n    <input type=\"text\" id=\"username\" name=\"username\" required><br>\r\n\r\n    <label for=\"password\">Пароль:</label>\r\n    <input type=\"password\" id=\"password\" name=\"password\" required><br>\r\n\r\n    <label for=\"role\">Роль:</label>\r\n    <input type=\"text\" id=\"role\" name=\"role\" required><br>\r\n\r\n    <button type=\"submit\">Зареєструватися</button>\r\n</form>\r\n</body>\r\n</html>\r\n");
	}
	public static void renderMap(gg.jte.html.HtmlTemplateOutput jteOutput, gg.jte.html.HtmlInterceptor jteHtmlInterceptor, java.util.Map<String, Object> params) {
		render(jteOutput, jteHtmlInterceptor);
	}
}
