package gg.jte.generated.ondemand;
import com.example.demo.entity.Category;
@SuppressWarnings("unchecked")
public final class JteeditcategoryGenerated {
	public static final String JTE_NAME = "edit-category.jte";
	public static final int[] JTE_LINE_INFO = {0,0,1,1,1,1,63,63,63,63,63,63,63,63,63,63,66,66,66,66,66,66,66,66,66,74,74,74,1,1,1,1};
	public static void render(gg.jte.html.HtmlTemplateOutput jteOutput, gg.jte.html.HtmlInterceptor jteHtmlInterceptor, Category category) {
		jteOutput.writeContent("\r\n<!DOCTYPE html>\r\n<html lang=\"uk\">\r\n<head>\r\n    <meta charset=\"UTF-8\">\r\n    <title>Редагування категорії</title>\r\n    <style>\r\n        body {\r\n            font-family: sans-serif;\r\n            background: #f3f3f3;\r\n            display: flex;\r\n            justify-content: center;\r\n            padding-top: 100px;\r\n        }\r\n\r\n        .form-box {\r\n            background: white;\r\n            padding: 30px;\r\n            border-radius: 10px;\r\n            box-shadow: 0 4px 20px rgba(0,0,0,0.1);\r\n            width: 400px;\r\n        }\r\n\r\n        h1 {\r\n            margin-bottom: 20px;\r\n        }\r\n\r\n        label {\r\n            display: block;\r\n            margin-bottom: 8px;\r\n            font-weight: 600;\r\n        }\r\n\r\n        input[type=\"text\"] {\r\n            width: 100%;\r\n            padding: 10px;\r\n            border: 1px solid #ccc;\r\n            border-radius: 6px;\r\n            margin-bottom: 20px;\r\n        }\r\n\r\n        button {\r\n            background: #007bff;\r\n            color: white;\r\n            border: none;\r\n            padding: 10px 20px;\r\n            border-radius: 6px;\r\n            cursor: pointer;\r\n        }\r\n\r\n        a {\r\n            display: inline-block;\r\n            margin-top: 10px;\r\n            color: #555;\r\n        }\r\n    </style>\r\n</head>\r\n<body>\r\n<div class=\"form-box\">\r\n    <h1>Редагування категорії</h1>\r\n    <form action=\"/categories/update\" method=\"post\">\r\n        <input type=\"hidden\" name=\"categoryId\"");
		var __jte_html_attribute_0 = category.getCategoryId();
		if (gg.jte.runtime.TemplateUtils.isAttributeRendered(__jte_html_attribute_0)) {
			jteOutput.writeContent(" value=\"");
			jteOutput.setContext("input", "value");
			jteOutput.writeUserContent(__jte_html_attribute_0);
			jteOutput.setContext("input", null);
			jteOutput.writeContent("\"");
		}
		jteOutput.writeContent(">\r\n\r\n        <label for=\"name\">Назва категорії:</label>\r\n        <input type=\"text\" id=\"name\" name=\"name\"");
		var __jte_html_attribute_1 = category.getName();
		if (gg.jte.runtime.TemplateUtils.isAttributeRendered(__jte_html_attribute_1)) {
			jteOutput.writeContent(" value=\"");
			jteOutput.setContext("input", "value");
			jteOutput.writeUserContent(__jte_html_attribute_1);
			jteOutput.setContext("input", null);
			jteOutput.writeContent("\"");
		}
		jteOutput.writeContent(" required>\r\n\r\n        <button type=\"submit\">Зберегти зміни</button>\r\n    </form>\r\n    <a href=\"/categories\">← Назад до списку</a>\r\n</div>\r\n</body>\r\n</html>\r\n");
	}
	public static void renderMap(gg.jte.html.HtmlTemplateOutput jteOutput, gg.jte.html.HtmlInterceptor jteHtmlInterceptor, java.util.Map<String, Object> params) {
		Category category = (Category)params.get("category");
		render(jteOutput, jteHtmlInterceptor, category);
	}
}
