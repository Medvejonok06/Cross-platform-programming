package gg.jte.generated.ondemand;
import java.util.List;
@SuppressWarnings("unchecked")
public final class JteindexGenerated {
	public static final String JTE_NAME = "index.jte";
	public static final int[] JTE_LINE_INFO = {0,0,1,1,1,1,5,5,7,7,9,10,10,11,11,11,12,12,14,14,18,18,19,19,19,20,20,23,23,24,24,24,25,25,25,1,2,3,3,3,3};
	public static void render(gg.jte.html.HtmlTemplateOutput jteOutput, gg.jte.html.HtmlInterceptor jteHtmlInterceptor, String name, boolean showWelcome, List<Integer> numbers) {
		jteOutput.writeContent("\r\n");
		gg.jte.generated.ondemand.layout.JtepageGenerated.render(jteOutput, jteHtmlInterceptor, new gg.jte.html.HtmlContent() {
			public void writeTo(gg.jte.html.HtmlTemplateOutput jteOutput) {
				jteOutput.writeContent("\r\n\r\n    ");
				jteOutput.writeContent("\r\n    ");
				if (showWelcome) {
					jteOutput.writeContent("\r\n        <h1>Привіт, ");
					jteOutput.setContext("h1", null);
					jteOutput.writeUserContent(name);
					jteOutput.writeContent("!</h1>\r\n    ");
				} else {
					jteOutput.writeContent("\r\n        <h1>Вітаю!</h1>\r\n    ");
				}
				jteOutput.writeContent("\r\n\r\n    <h2>Числа:</h2>\r\n    <ul>\r\n        ");
				for (int i : numbers) {
					jteOutput.writeContent("\r\n            <li>");
					jteOutput.setContext("li", null);
					jteOutput.writeUserContent(i);
					jteOutput.writeContent("</li>\r\n        ");
				}
				jteOutput.writeContent("\r\n    </ul>\r\n\r\n    ");
				gg.jte.generated.ondemand.JtegreetingGenerated.render(jteOutput, jteHtmlInterceptor, "Світ", 1, 2, 3);
				jteOutput.writeContent("\r\n    ");
			}
		});
		jteOutput.writeContent("\r\n");
	}
	public static void renderMap(gg.jte.html.HtmlTemplateOutput jteOutput, gg.jte.html.HtmlInterceptor jteHtmlInterceptor, java.util.Map<String, Object> params) {
		String name = (String)params.get("name");
		boolean showWelcome = (boolean)params.get("showWelcome");
		List<Integer> numbers = (List<Integer>)params.get("numbers");
		render(jteOutput, jteHtmlInterceptor, name, showWelcome, numbers);
	}
}
