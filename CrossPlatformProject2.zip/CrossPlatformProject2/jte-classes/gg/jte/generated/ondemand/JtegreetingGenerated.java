package gg.jte.generated.ondemand;
@SuppressWarnings("unchecked")
public final class JtegreetingGenerated {
	public static final String JTE_NAME = "greeting.jte";
	public static final int[] JTE_LINE_INFO = {0,0,0,0,0,3,3,3,4,4,4,4,4,4,5,5,6,6,6,0,0,0,0};
	public static void render(gg.jte.html.HtmlTemplateOutput jteOutput, gg.jte.html.HtmlInterceptor jteHtmlInterceptor, String name, int... times) {
		jteOutput.writeContent("\r\n");
		for (int i : times) {
			jteOutput.writeContent("\r\n    <p>Привіт, ");
			jteOutput.setContext("p", null);
			jteOutput.writeUserContent(name);
			jteOutput.writeContent("! (");
			jteOutput.setContext("p", null);
			jteOutput.writeUserContent(i);
			jteOutput.writeContent(")</p>\r\n");
		}
		jteOutput.writeContent("\r\n");
	}
	public static void renderMap(gg.jte.html.HtmlTemplateOutput jteOutput, gg.jte.html.HtmlInterceptor jteHtmlInterceptor, java.util.Map<String, Object> params) {
		String name = (String)params.getOrDefault("name", "User");
		render(jteOutput, jteHtmlInterceptor, name);
	}
}
