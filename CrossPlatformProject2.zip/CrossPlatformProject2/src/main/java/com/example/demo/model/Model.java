package main.java.com.example.demo.model;

import java.util.List;

public class Model {
    public String name = "Svyatoslav";
    public List<Entry> entries;

    public Model(String name, List<Entry> entries) {
        this.name = name;
        this.entries = entries;
    }
}
