package main.java.com.example.demo.model;

public class Entry {
    public String title;
    public String subtitle;

    public Entry(String title, String subtitle) {
        this.title = title;
        this.subtitle = subtitle;
    }

    public String getTitle() {
        return title;
    }

    public String getSubtitle() {
        return subtitle;
    }
}
